package com.u2.web.SpringDojo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDojoApplicationTests {

	@Test
	void contextLoads() {
	}

}
